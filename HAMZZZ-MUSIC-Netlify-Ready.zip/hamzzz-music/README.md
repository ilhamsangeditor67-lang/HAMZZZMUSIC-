# HAMZZZ MUSIC — Glass 3D (Netlify-ready)

Website musik dengan antarmuka Glass 3D, pencarian metadata SpotifyPlay/SpotMP3 melalui Netlify Functions, Spotify Embed untuk pemutaran, status baterai HP bila browser mendukung, serta percobaan membaca baterai headset melalui Web Bluetooth bila perangkat mendukungnya.

## Deploy langsung ke Netlify

1. Ekstrak ZIP ini.
2. Cara termudah: unggah seluruh isi folder `hamzzz-music` ke repository GitHub, lalu di Netlify pilih **Add new project → Import an existing project** dan hubungkan repository tersebut.
3. Biarkan Netlify membaca konfigurasi dari `netlify.toml`. Build command boleh kosong; publish directory sudah diatur ke `public`.
4. Pilih **Deploy**. Netlify akan membangun situs sekaligus menerbitkan dua Functions.

Alternatif lewat terminal dengan Netlify CLI (setelah Node.js 18+ terpasang):

```bash
npx netlify-cli login
npx netlify-cli deploy --prod
```

Saat diminta, tautkan ke situs Netlify yang sudah ada atau buat situs baru. **Jangan gunakan drag-and-drop folder `public` saja**, karena itu hanya menerbitkan file statis dan tidak menyertakan Functions. Konfigurasi build sudah tersedia di `netlify.toml`.

## Endpoint

- `/api/health` — status layanan.
- `/api/search?q=nama%20lagu` — pencarian metadata melalui SpotifyPlay/SpotMP3.

## Menjalankan versi lokal

Perlu Node.js 18 atau lebih baru:

```bash
npm start
```

Buka `http://localhost:3000`. Server lokal memakai `server/index.js`; versi Netlify memakai fungsi di `netlify/functions/`.

## Catatan kompatibilitas

- Pencarian membutuhkan layanan upstream SpotMP3 yang masih aktif dan mempertahankan format API. Jika layanan itu berubah atau membatasi permintaan, pencarian dapat gagal meskipun deploy Netlify berhasil.
- Pemutaran memakai Spotify Embed resmi. Kontrol aplikasi tidak mengambil atau mengunduh file audio.
- Battery Status API tidak tersedia di semua browser/perangkat.
- Pembacaan baterai headset melalui Web Bluetooth bergantung pada dukungan browser, izin pengguna, dan layanan baterai GATT pada headset. Tidak semua headset atau browser Android mendukungnya.
- Gunakan HTTPS (Netlify menyediakannya) untuk fitur perangkat yang memerlukan secure context.
