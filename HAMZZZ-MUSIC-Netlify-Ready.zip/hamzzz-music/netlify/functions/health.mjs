export default async () => new Response(JSON.stringify({
  ok: true,
  service: 'HAMZZZ MUSIC',
  searchProvider: 'SpotifyPlay / SpotMP3',
  audioMode: 'Spotify embed'
}), {
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
});
