const API = (process.env.SPOTMP3_API_BASE || 'https://spotmp3.net/api/v1').replace(/\/+$/, '');

export default async (request) => {
  const url = new URL(request.url);
  const q = (url.searchParams.get('q') || '').trim().slice(0, 160);
  if (!q) return json({ error: 'Masukkan judul lagu atau nama artis.' }, 400);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 18000);
  try {
    const upstream = new URL(`${API}/search`);
    upstream.searchParams.set('q', q);
    upstream.searchParams.set('limit', '20');
    upstream.searchParams.set('offset', '0');

    const response = await fetch(upstream, {
      signal: controller.signal,
      headers: { 'User-Agent': 'HAMZZZ-MUSIC/1.0', Accept: 'application/json' }
    });
    if (!response.ok) throw new Error(`Upstream HTTP ${response.status}`);

    const payload = await response.json();
    let items = Array.isArray(payload?.items) ? payload.items : [];
    if (!items.length && Array.isArray(payload?.sections)) {
      const section = payload.sections.find((item) => item.type === 'track');
      items = Array.isArray(section?.items) ? section.items : [];
    }

    const tracks = items.filter((item) => item?.id).map((item) => ({
      id: String(item.id),
      title: item.title || 'Unknown title',
      artist: item.subtitle || 'Unknown artist',
      album: item.album || null,
      duration_ms: Number.isFinite(Number(item.duration_ms)) ? Number(item.duration_ms) : null,
      cover: item.cover || null,
      spotify_url: item.url || `https://open.spotify.com/track/${encodeURIComponent(item.id)}`
    }));

    return json({ query: q, total: tracks.length, tracks, provider: 'SpotifyPlay / SpotMP3' });
  } catch (error) {
    return json({
      error: 'Pencarian SpotifyPlay sedang tidak tersedia. Coba lagi beberapa saat.',
      ...(process.env.CONTEXT === 'dev' ? { details: error.message } : {})
    }, 502);
  } finally {
    clearTimeout(timeout);
  }
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff'
    }
  });
}
