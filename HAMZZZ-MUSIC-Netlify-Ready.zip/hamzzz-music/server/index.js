'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const PORT = Number(process.env.PORT || 3000);
const API = (process.env.SPOTMP3_API_BASE || 'https://spotmp3.net/api/v1').replace(/\/+$/, '');
const ROOT = path.join(__dirname, '..', 'public');
const MIME = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.json':'application/json; charset=utf-8', '.svg':'image/svg+xml' };
function send(res, status, data, type='application/json; charset=utf-8') { res.writeHead(status, {'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}); res.end(type.startsWith('application/json') ? JSON.stringify(data) : data); }
const server = http.createServer(async (req,res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/api/health') return send(res,200,{ok:true,service:'HAMZZZ MUSIC',searchProvider:'SpotifyPlay / SpotMP3',audioMode:'Spotify embed'});
  if (url.pathname === '/api/search') {
    const q = (url.searchParams.get('q') || '').trim().slice(0,160);
    if (!q) return send(res,400,{error:'Masukkan judul lagu atau nama artis.'});
    try {
      // Search metadata only. Playback uses the official Spotify embed, not scraped MP3 files.
      const upstream = new URL(`${API}/search`); upstream.searchParams.set('q',q); upstream.searchParams.set('limit','20'); upstream.searchParams.set('offset','0');
      const controller = new AbortController(); const timeout = setTimeout(() => controller.abort(), 18000);
      let response; try { response = await fetch(upstream, { signal:controller.signal, headers:{'User-Agent':'HAMZZZ-MUSIC/1.0','Accept':'application/json'} }); } finally { clearTimeout(timeout); }
      if (!response.ok) throw Object.assign(new Error(`Upstream HTTP ${response.status}`), { upstreamStatus:response.status });
      const payload = await response.json() || {};
      let items = Array.isArray(payload.items) ? payload.items : [];
      if (!items.length && Array.isArray(payload.sections)) {
        const section = payload.sections.find(s => s.type === 'track');
        items = Array.isArray(section?.items) ? section.items : [];
      }
      const tracks = items.filter(x => x && x.id).map(x => ({
        id:String(x.id), title:x.title || 'Unknown title', artist:x.subtitle || 'Unknown artist',
        album:x.album || null, duration_ms:Number.isFinite(Number(x.duration_ms)) ? Number(x.duration_ms) : null,
        cover:x.cover || null, spotify_url:x.url || `https://open.spotify.com/track/${encodeURIComponent(x.id)}`
      }));
      return send(res,200,{query:q,total:tracks.length,tracks,provider:'SpotifyPlay / SpotMP3'});
    } catch (error) {
      const status = error.upstreamStatus || 502;
      return send(res,502,{error:'Pencarian SpotifyPlay sedang tidak tersedia. Coba lagi beberapa saat.',details:process.env.NODE_ENV === 'development' ? error.message : undefined,upstreamStatus:status});
    }
  }
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === '/') pathname = '/index.html';
  const file = path.resolve(ROOT, '.' + pathname);
  if (!file.startsWith(ROOT + path.sep)) return send(res,403,{error:'Forbidden'});
  fs.readFile(file,(err,content)=>{
    if (err) return send(res,404,{error:'Not found'});
    send(res,200,content,MIME[path.extname(file)] || 'application/octet-stream');
  });
});
server.listen(PORT,()=>console.log(`HAMZZZ MUSIC running at http://localhost:${PORT}`));
