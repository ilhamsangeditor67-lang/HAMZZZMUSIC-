# SONORA by HAMZZZ — Netlify Ready

## Upload ke Netlify
1. Ekstrak ZIP ini.
2. Buka Netlify dan pilih **Add new site → Deploy manually** (atau Netlify Drop).
3. Upload folder hasil ekstrak yang berisi `index.html`, `netlify.toml`, `package.json`, dan folder `netlify/`.
   - Jangan upload folder `public` saja.
   - Jangan upload ZIP lama yang belum diperbaiki.
4. Setelah deploy, buka **Site configuration → Environment variables**.
5. Tambahkan:
   - `SPOTIFY_CLIENT_ID` = Client ID dari Spotify Developer Dashboard
   - `SPOTIFY_CLIENT_SECRET` = Client Secret dari Spotify Developer Dashboard
6. Trigger **Redeploy** setelah environment variables disimpan.

## Fitur dan batasan
- Pencarian Spotify dijalankan melalui `/.netlify/functions/search`.
- Pemutaran memakai Spotify Embed resmi.
- Lirik dicari dari LRCLIB.
- Baterai dan informasi perangkat mengikuti dukungan browser.
- Untuk fungsi Netlify, kredensial Spotify hanya disimpan sebagai environment variables, bukan di frontend.

## Penting
Jangan commit atau membagikan Spotify Client Secret. Jika secret pernah tertanam di file yang dibagikan, rotasi dari Spotify Developer Dashboard.
