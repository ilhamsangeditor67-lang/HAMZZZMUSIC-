const axios = require("axios");

let cachedToken = null;
let tokenExpiresAt = 0;

async function getSpotifyToken() {
  if (cachedToken && Date.now() < tokenExpiresAt) return cachedToken;

  const clientId = process.env.SPOTIFY_CLIENT_ID;
  const clientSecret = process.env.SPOTIFY_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    throw new Error("Spotify API credentials belum diatur di Netlify environment variables.");
  }

  const basic = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const { data } = await axios.post(
    "https://accounts.spotify.com/api/token",
    "grant_type=client_credentials",
    { headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded"
    }}
  );

  cachedToken = data.access_token;
  tokenExpiresAt = Date.now() + (data.expires_in - 60) * 1000;
  return cachedToken;
}

exports.handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  const q = (event.queryStringParameters && event.queryStringParameters.q || "").trim();
  if (!q) {
    return { statusCode: 400, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Query wajib diisi" }) };
  }

  try {
    const token = await getSpotifyToken();
    const { data } = await axios.get("https://api.spotify.com/v1/search", {
      params: { q, type: "track", limit: 10 },
      headers: { Authorization: `Bearer ${token}` }
    });

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=60" },
      body: JSON.stringify({
        tracks: data.tracks.items.map(item => ({
          title: item.name,
          artist: item.artists.map(a => a.name).join(", "),
          link: item.external_urls.spotify,
          thumbnail: item.album.images[0]?.url || ""
        }))
      })
    };
  } catch (error) {
    console.error("Spotify search error:", error.response?.data || error.message);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Spotify search gagal", detail: error.response?.data?.error?.message || error.message })
    };
  }
};
